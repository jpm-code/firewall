========================================================================
    CONSOLE APPLICATION : PassThrough_c Project Overview
========================================================================

This sample filters all TCP connections and UDP datagrams in pass-though mode,
and prints the information about the filtered connections to standard output.

The project uses C interface of nfapi.