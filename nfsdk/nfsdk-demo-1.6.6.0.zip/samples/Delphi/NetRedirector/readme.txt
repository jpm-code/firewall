NetRedirector:
- Allows redirecting outgoing TCP connections to specified host:port.
- Creates HTTP tunnels in case if remote proxy supports this feature.
- Redirects DNS requests to specified host.