========================================================================
    CONSOLE APPLICATION : PassThrough Project Overview
========================================================================
The sample filters all non-loopback IP packets in pass-through mode,
and prints the information about all called events to standard console output.
