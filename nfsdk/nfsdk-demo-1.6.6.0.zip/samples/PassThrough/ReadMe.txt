========================================================================
    CONSOLE APPLICATION : PassThrough Project Overview
========================================================================

This sample filters all TCP connections and UDP datagrams in pass-though mode,
and prints the information about the filtered connections to standard output.