========================================================================
    CONSOLE APPLICATION : DnsRedirector Project Overview
========================================================================

This sample redirects DNS requests to opendns.com server.