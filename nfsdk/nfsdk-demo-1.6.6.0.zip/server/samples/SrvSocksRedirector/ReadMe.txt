========================================================================
    CONSOLE APPLICATION : SrvSocksRedirector Project Overview
========================================================================
The sample redirects TCP and UDP to the specified SOCKS5 proxy

