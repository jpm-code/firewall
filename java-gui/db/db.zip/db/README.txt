Need run the Controller with java and all the jars in the folder, else it spits out errors. Also, exception handling needs adding for connecting to the db in Java.

